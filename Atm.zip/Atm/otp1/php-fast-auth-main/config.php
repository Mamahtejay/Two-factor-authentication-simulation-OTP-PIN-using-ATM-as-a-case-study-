<?php

$host = 'localhost'; 
$username = 'root';
$password = '';
$dbname = 'test';

$db = new mysqli($host, $username, $password, $dbname);