-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2023 at 06:19 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atm`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `transaction_display` ()  NO SQL
select * from transaction where transaction_date not BETWEEN 2019-10-31 and 2019-08-30 GROUP by transaction_id,transaction_type,user_id,transaction_status,transaction_date$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `Account_number` int(10) NOT NULL,
  `Balance` int(50) NOT NULL,
  `Account_type` varchar(255) NOT NULL,
  `user_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Account_number`, `Balance`, `Account_type`, `user_id`) VALUES
(1000, 55000, 'savings', 100),
(1001, 10900, 'current', 101),
(1002, 19200, 'savings', 102),
(1003, 11200, 'current', 103),
(1004, 103200, 'savings', 104),
(1005, 78950, 'savings', 105),
(1006, 4000, 'savings', 106),
(1007, 47042, 'savings', 107),
(1008, 52200, 'current', 108),
(1009, 58200, 'savings', 109);

--
-- Triggers `account`
--
DELIMITER $$
CREATE TRIGGER `logs` AFTER UPDATE ON `account` FOR EACH ROW insert into logs values(null, new.user_id,new.balance,now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_pin` int(11) NOT NULL,
  `atm_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_pin`, `atm_id`) VALUES
(500, 1122, 120),
(501, 2244, 121),
(502, 5566, 122),
(503, 7890, 123),
(504, 9810, 124),
(505, 1999, 125),
(506, 1887, 126),
(507, 4596, 127),
(508, 8988, 128),
(509, 9999, 129);

-- --------------------------------------------------------

--
-- Table structure for table `atm`
--

CREATE TABLE `atm` (
  `atm_id` int(11) NOT NULL,
  `atm_location` varchar(255) NOT NULL,
  `available_cash` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `atm`
--

INSERT INTO `atm` (`atm_id`, `atm_location`, `available_cash`) VALUES
(120, 'auk', 80500),
(121, 'kats', 150000),
(122, 'auk001', 70000),
(123, 'layout', 20000),
(124, 'katsina', 80000),
(125, 'kt 001', 80000),
(126, 'kt01', 70000),
(127, 'kt003', 100000),
(128, 'Layout', 100500),
(129, 'auk002', 70000);

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `Bank_name` varchar(255) NOT NULL,
  `Bank_id` int(11) NOT NULL,
  `Branch_Location` varchar(255) NOT NULL,
  `account` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`Bank_name`, `Bank_id`, `Branch_Location`, `account`) VALUES
('Bank', 1, 'katsina', 1000),
('Bank', 2, 'Layout', 1001),
('Bank', 3, 'auk', 1002),
('Bank', 4, 'auk01', 1003),
('Bank ', 5, 'auk02', 1004),
('Bank ', 6, 'auk 003', 1005),
('bank', 7, 'kat', 1006),
('uba Bnak', 8, 'katsin', 1007);

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `card_no` int(11) NOT NULL,
  `card_pin` int(11) NOT NULL,
  `email` text NOT NULL,
  `balance` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `otp` varchar(6) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `card`
--

INSERT INTO `card` (`card_no`, `card_pin`, `email`, `balance`, `user_id`, `otp`) VALUES
(123456, 9001, 'abdulrahman762@gmail.com', 78950, 105, ''),
(123965, 9110, '0', 55000, 109, ''),
(145672, 1837, '0', 55000, 100, ''),
(312315, 4142, '0', 11200, 103, ''),
(423415, 1312, '0', 19200, 102, ''),
(456789, 1002, '0', 4000, 106, ''),
(512345, 1131, '0', 10900, 101, ''),
(765345, 4810, '0', 52200, 108, ''),
(914321, 8198, '0', 103200, 104, ''),
(987651, 1113, '0', 47042, 107, '');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `balance` varchar(20) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `balance`, `created_date`) VALUES
(1, 100, '60400', '2019-11-14 10:26:44'),
(2, 100, '60200', '2019-11-14 10:28:26'),
(3, 100, '60000', '2019-11-14 10:59:18'),
(4, 100, '59000', '2019-11-14 13:40:20'),
(5, 100, '58200', '2019-11-14 13:45:22'),
(6, 101, '700', '2019-11-14 13:47:01'),
(7, 101, '-100', '2019-11-14 13:47:23'),
(8, 101, '10000', '2019-11-14 13:48:02'),
(9, 101, '9900', '2019-11-14 13:50:13'),
(10, 101, '10400', '2019-11-14 13:53:26'),
(11, 100, '57700', '2019-11-14 13:53:26'),
(12, 101, '10500', '2019-11-14 13:56:40'),
(13, 100, '57600', '2019-11-14 13:56:40'),
(14, 100, '57400', '2019-11-14 14:48:47'),
(15, 101, '10600', '2019-11-14 14:49:52'),
(16, 100, '57300', '2019-11-14 14:49:53'),
(17, 101, '10700', '2019-11-14 14:50:22'),
(18, 100, '57200', '2019-11-14 14:50:22'),
(19, 100, '56200', '2019-11-29 11:05:36'),
(20, 101, '10800', '2019-12-03 06:43:14'),
(21, 100, '56100', '2019-12-03 06:43:14'),
(22, 100, '55100', '2019-12-03 11:10:42'),
(23, 101, '10900', '2019-12-03 11:13:19'),
(24, 100, '55000', '2019-12-03 11:13:20'),
(25, 105, '78950', '2023-10-20 03:08:25');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_date` date NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `transaction_status` varchar(255) NOT NULL,
  `transaction_type` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_date`, `transaction_id`, `transaction_status`, `transaction_type`, `user_id`) VALUES
('2019-11-10', 1, 'Successful', 'savings', 108),
('2019-11-14', 2, 'Successful', 'Savings', 100),
('2019-10-17', 3, 'Successful', 'current', 101),
('2019-10-18', 4, 'Failed', 'savings', 102),
('2019-09-14', 5, 'Successful', 'current', 103),
('2019-10-18', 6, 'Failed', 'Savings', 104),
('2019-11-13', 7, 'Successful', 'savings\r\n', 105),
('2019-10-28', 8, 'Failed', 'current', 106),
('2019-11-10', 9, 'Successful', 'savings', 107);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_no` int(11) NOT NULL,
  `DOB` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `address`, `contact_no`, `DOB`) VALUES
(105, 'Maryam', 'Sulaiman', 'Auk', 803331050, '1999-06-29');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `firstname` text NOT NULL,
  `middlename` text,
  `lastname` text NOT NULL,
  `card_pin` int(11) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `otp_expiration` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `lastname`, `card_pin`, `email`, `password`, `otp`, `otp_expiration`, `date_created`) VALUES
(1, 'John', 'D', 'Smith', 0, 'jsmith231415@gmail.com', '$2y$10$Fv0wfP2pKATelsPbWZJPoePlYkWjOHV1CfZoFDTrtZFG/cUILx6zu', '904722', '2022-02-12 06:27:00', '2022-02-12 09:12:16'),
(2, 'Claire', 'C', 'Blake', 0, 'cblake.6231415@gmail.com', '$2y$10$qQUQ6jdsLld0i/5Y0Px9YuB4hoyWrmromwOkwD4H5XWYan4h/yycm', NULL, NULL, '2022-02-12 09:14:20'),
(3, 'Mark', 'D', 'Cooper', 0, 'mcooper@gmail.com', '$2y$10$7Shp0oPlNZfRY3BqnQ5fUebNZTeBieUsqJw8uLuqVloSsxFFqvGKi', NULL, NULL, '2022-02-12 11:45:13'),
(0, 'Abdulrahman', 'Muhammed', 'Shuaibu', 0, 'abdulrahmanar762@gmail.com', '$2y$10$cQBrjL6pwxIebIQl/A.syuiXnGA4XxWcaFtlS5l1DOnuVMn88T11u', NULL, NULL, '2023-10-24 20:57:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`Account_number`,`user_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `Balance` (`Balance`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD KEY `atm_id` (`atm_id`);

--
-- Indexes for table `atm`
--
ALTER TABLE `atm`
  ADD PRIMARY KEY (`atm_id`),
  ADD KEY `atm_id` (`atm_id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`Bank_id`);

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`card_no`),
  ADD KEY `balance` (`balance`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `Account_number` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1010;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `account_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`atm_id`) REFERENCES `atm` (`atm_id`);

--
-- Constraints for table `card`
--
ALTER TABLE `card`
  ADD CONSTRAINT `card_ibfk_1` FOREIGN KEY (`balance`) REFERENCES `account` (`Balance`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `card_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `account` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
