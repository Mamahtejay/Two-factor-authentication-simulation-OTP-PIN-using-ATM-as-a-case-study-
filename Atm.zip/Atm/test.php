<?php

echo  password_hash('0000', PASSWORD_DEFAULT, []);
  